import vegaEmbed from 'vega-embed';
import { createGraphQLClient, gql, request } from "@solid-primitives/graphql";
import { createSignal, createEffect, For, Show, mergeProps } from "solid-js";
import { timeFormat, isoParse } from "d3-time-format";
//import * as Aq from 'arquero';


const query = createGraphQLClient("http://localhost:8080/v1/graphql");
const [sortDirection, setSortDirection] = createSignal();
const [action, setAction] = createSignal();
const format = timeFormat("%y-%m-%d");
const formatDate = (date) => format(isoParse(date));



const VegaBar = (props) => {
  //const [jdata, setJdata] = createSignal();
  const nprops = mergeProps(props);

  /*
  let jdata = Aq.from( nprops.info);
  jdata = jdata.objects();
  */
  
//console.log(nprops.info)
  const vspec = {
    $schema: "https://vega.github.io/schema/vega-lite/v5.json",
    description: "A simple bar chart with embedded data.",
    width: 400,
    height: 400,
    data: { values: nprops.info },
    mark: "bar",
    encoding: {
      x: { field: "date", type: "temporal" },
      y: { field: "newCases", type: "quantitative" },
    },
  };
  return (
    
    <div>{vegaEmbed('#root', vspec) }</div>
    
  )
}

function App() {



  const [gdata] = query(
    gql`
      query ($sortDirection: [Disease_order_by!], $action: Disease_bool_exp) {
        Disease(order_by: $sortDirection, where: $action) {
          date
          newCases
        }
      }
    `,
    () => ({ sortDirection: sortDirection(), action: action() })
  );

/*
let VlSpec = {
  $schema: 'https://vega.github.io/schema/vega-lite/v5.json',
  description: 'A simple bar chart with embedded data.',
  data: gdata()["Disease"],
  mark: 'bar',
  encoding: {
    x: {field: 'date', type: 'temporal'},
    y: {field: 'newCases', type: 'quantitative'}
  }
};
*/

let viz = <div id="vis"></div>;
document.body.appendChild(viz);


/*
let jdata = Aq.from( gdata()).objects();
  
  jdata.print()
  jdata = jdata.objects();
*/

  return (
    <Show when={gdata()} fallback={<div>Loading...</div>}>
      <VegaBar
        info={ gdata()["Disease"] }
        
      />
    </Show>
  );
}

export default App;
